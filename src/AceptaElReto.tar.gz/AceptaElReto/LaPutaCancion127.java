package AceptaElReto;

import java.util.Scanner;

/**
 * Created by 48089748z on 02/02/16.
 */
public class LaPutaCancion127
{

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String numero = sc.nextLine();
        String[] array = new String[Integer.parseInt(numero)];
        String[] results = new String[Integer.parseInt(numero)];

        for (int x=0; x<array.length; x++)
        {
            array[x] = sc.nextLine();
            results[x] = calc(array[x]);
        }
        print(results);
    }
    public static String calc(String linea)
    {
        Integer camas;
        Integer songTimes;
        String [] merda = linea.split(" ");
        camas = Integer.parseInt(merda[merda.length-2]);
        if (camas==0)
        {
            return"NADIE TIENE CAMA";
        }
        else
        {
            songTimes = Integer.parseInt(merda[merda.length -1]);
            String [] peregrinos = new String[merda.length-3];
            for (int x=0; x<peregrinos.length; x++)
            {
                peregrinos[x]= merda[x];
                System.out.println(peregrinos[x]);
            }
            System.out.println(songTimes+"  "+camas);


            return "";
        }
    }
    public static void print(String[] results)
    {
        for (int x=0; x<results.length; x++)
        {
            System.out.println(results[x]);
        }
    }
}
